package com.example.AttendenceApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttendenceAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
